<?php

/*

Copyright (c) 2013 Charles Iliya Krempeaux

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

*/


// References: http://datascholars.com/post/2013/03/10/facebook_gdf/
//             http://changelog.ca/log/2013/03/10/facebook_gdf


// Author Info:
//
//         Name: Charles Iliya Krempeaux
//       E-mail: charles@reptile.ca
//     Homepage: http://changelog.ca/
//         Blog: http://changelog.ca/log
//         Card: http://reiver.ca/
//      Twitter: http://twitter.com/reiver
//



//
// M A I N
//

    // Deal with args.
        if (  !is_array($argv)  ) {
/////////// EXIT
            exit(1);
        }

        $args = Args::getInstance();

        //DEBUG
        //echo 'ARGS: ', var_export($args), "\n";


    // See if user called --help switch.
        if (  $args->getSwitch('help', false) || 1 == count($argv)  ) {
            echo_help();
/////////// EXIT
            exit(0);
        }



    // Get access_token, via the user supplied --access_token switch.
        $access_token = $args->getSwitch('access_token');

        if (  !is_string($access_token)  ) {
            // Error.
            fwrite(STDERR, 'ERROR: Missing Facebook access token. Use --access_token switch.'."\n");
            echo_help();
/////////// EXIT
            exit(1);
        }

        //DEBUG
        if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
            echo 'Access Token: ', $access_token, "\n";
        }


    // Get person's information.  (The *person* is whomever the Facebook access token is for.)
        $me_datum = fb_graph_get_decoded_json('/me', $access_token, $args->getSwitch('verbose', false), $args->getSwitch('debug', false));


    // Get person's list of friends.
        $friends_data = array();

        $friends_result = fb_graph_get_decoded_json('/me/friends', $access_token, $args->getSwitch('verbose', false), $args->getSwitch('debug', false));

        if (  isset($friends_result['data']) && is_array($friends_result['data']) && !empty($friends_result['data'])  ) {
            $friends_data = array_merge($friends_data,  $friends_result['data']);
        }

        //DEBUG
        if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
            echo 'Paging Next URL: ', var_export(@$friends_result['paging']['next'],true), "\n";
        }

        if (  isset($friends_result['paging']) && is_array($friends_result['paging'])  ) {
            if (  isset($friends_result['paging']['next']) && is_string($friends_result['paging']['next'])  ) {
                $i=0;
                do {
                    $next_href = $friends_result['paging']['next'];

                    //DEBUG
                    if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
                        echo '[LOOP][',$i,']: Next (Paging Next) URL: ', var_export($next_href,true), "\n";
                    }

                    $friends_result = file_get_decoded_json($next_href, $args->getSwitch('verbose', false), $args->getSwitch('debug', false));

                    //DEBUG
                    if (  true === $args->getSwitch('debug', false)  ) {
                        echo '[LOOP][',$i,']: Results: ', var_export($friends_result,true), "\n";
                    }

                    if (  $friends_result['data']  ) {

                        //DEBUG
                        if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
                            echo '[LOOP][',$i,']: Num Data Merged: ', count($friends_result['data']), "\n";
                        }

                        $friends_data = array_merge($friends_data,  $friends_result['data']);
                    } else {

                        //DEBUG
                        if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
                            echo '[LOOP][',$i,']: No Data To Merge.', "\n";
                        }
                    }

                    $i++;
                } while (  isset($friends_result['data']) && is_array($friends_result['data']) && !empty($friends_result['data'])  );
            }
        }


    // Figure out the output file name.
        $output_fn = $args->getSwitch('output', 'fbsn_1.gdf');

        //DEBUG
        if (  true === $args->getSwitch('verbose', false) || true === $args->getSwitch('debug', false)  ) {
            echo 'Output File Name: ', $output_fn, "\n";
        }


    // Output.
        //DEBUG
        if (  true === $args->getSwitch('debug', false)  ) {
            echo 'OUTPUT to ', var_export($output_fn,true) ,'....', "\n\n";
        }

        $output_fd = fopen($output_fn, 'w');

        $s = "nodedef> name,label\n";
        fwrite($output_fd, $s);
        //DEBUG
        if (  true === $args->getSwitch('debug', false)  ) {
            echo $s;
        }

        $s = 'n'. $me_datum['id'] .','.'"'. addslashes($me_datum['name']) ."\"\n";
        fwrite($output_fd, $s);
        //DEBUG
        if (  true === $args->getSwitch('debug', false)  ) {
            echo $s;
        }


        if (  is_array($friends_data) && !empty($friends_data)  ) {
            foreach ($friends_data AS $k => $friend_datum) {

                $s = 'n'. $friend_datum['id'] .','.'"'. addslashes($friend_datum['name']) ."\"\n";
                fwrite($output_fd, $s);
                //DEBUG
                if (  true === $args->getSwitch('debug', false)  ) {
                    echo $s;
                }


            } // foreach
        }


        $s = "edgedef> node1,node2\n";
        fwrite($output_fd, $s);
        //DEBUG
        if (  true === $args->getSwitch('debug', false)  ) {
            echo $s;
        }

        if (  is_array($friends_data) && !empty($friends_data)  ) {
            foreach ($friends_data AS $k => $friend_datum) {

                $s = 'n'. $me_datum['id'] .',n'. $friend_datum['id'] ."\n";
                fwrite($output_fd, $s);
                //DEBUG
                if (  true === $args->getSwitch('debug', false)  ) {
                    echo $s;
                }

            } // foreach
        }


        fclose($output_fd);


    // Exit.
        exit(0);


// P R O C E D U R E S //////////////////////////////////////////////////////////////////////////////////////////////////////
    function fb_graph_get_decoded_json($path, $access_token, $verbose=false, $debugging=false)
    {
        $api_href = 'https://graph.facebook.com/';
        $api_href .= $path;
        if (  false === strpos($api_href, '?')  ) {
            $api_href .= '?';
        } else {
            $api_href .= '&';
        }
        $api_href .= 'access_token=';
        $api_href .= urlencode($access_token);

        //DEBUG
        if (  $verbose || $debugging  ) {
            echo 'API HRef: ', $api_href, "\n";
        }


        return file_get_decoded_json($api_href, $verbose, $debugging);
    }
//-------------------------------------------------------------------------------------------------------------------------//
    function file_get_decoded_json($href, $verbose=false, $debugging=false)
    {
        $json = file_get_contents($href);

        //DEBUG
        if (  $debugging  ) {
            echo 'JSON: ', $json, "\n";
        }



        $result = json_decode($json, true);

        //DEBUG
        if (  $debugging  ) {
            echo 'Result: ', var_export($result,true), "\n";
        }


        return $result;
    }

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=//

    function echo_help()
    {
            global $argv;

            $filename = $argv[0];
            $pos = strrpos($filename, '/');
            if (  false !== $pos  ) {
                $filename = substr($filename, 1+$pos);
            }

            echo "\n"
               , 'Exports your Facebook social network to a GDF file.', "\n"
               , "\n"
               , "\n", 'switches:'
               , "\n"
               , "\t", '--access_token  The Facebook access token.', "\n"
               , "\t", '--help          Shows this message.', "\n"
               , "\t", '--output        The name of the output GDF file. (Default: "fbsn_1.gdf").', "\n"
               , "\t", '--verbose       Shows progress messages.', "\n"
               , "\t", '--debug         Shows debug messages.', "\n"
               , "\n"
               , "\n", 'example:'
               , "\n"
               , "\t", 'php ', $filename, ' --access_token=12345AbCdE', "\n"
               , "\n"
               , "\n"
               ;
    }

////////////////////////////////////////////////////////////////////////////////////////////////////// P R O C E D U R E S //



// C L A S S E S ////////////////////////////////////////////////////////////////////////////////////////////////////////////
class Args
{
    private $argv     = null;
    private $switches = array();
    private $params   = array();


    public static function parseArgv($argv, $skip_item_zero = true)
    {
        // Initialize.
            $switches = array();
            $params   = array();


        // See if should skip first item.  (This is because $argv[0] is the script file name, in general.)
            if (  $skip_item_zero && isset($argv[0])  ) {
                unset($argv[0]);
            }


        // Parse.
            if (  is_array($argv) && !empty($argv)  ) {
                foreach ($argv AS $k => $v) {

                    $strlen = strlen($v);

                    if (  2 < $strlen && '-' == $v{0} && '-' == $v{1}  ) {
                        $pos_equal = strpos($v, '=');

                        if (  false === $pos_equal  ) {
                            $name = substr($v, 2);

                            $switches[$name] = true;
                        } else {
                            $name = substr($v, 2, ($pos_equal-2) );
                            $value = substr($v, 1+$pos_equal);

                            $switches[$name] = $value;
                        }
                    } elseif (  '-' == $v{0}  ) {
                        $name = substr($v, 1);

                        $switches[$name] = true;
                    } else {
                        $params[] = $v;
                    }

                } // foreach
            }


        // Return.
            $result = array();
            $result['switches'] = $switches;
            $result['params']  = $params;

            return $result;
    }


    private function __construct($argv)
    {
        $this->init($argv);
    }

    private function init($argv)
    {
        // Set field(s).
            $this->argv = $argv;


        // Parse argv.
            if (  is_array($this->argv) && !empty($this->argv)  ) {

                $parse_results = self::parseArgv($this->argv);
                if (  is_array($parse_results) && !empty($parse_results)  ) {

                    if (  isset($parse_results['switches']) ) {
                        $this->switches = $parse_results['switches'];
                    }
                    if (  isset($parse_results['params']) ) {
                        $this->params = $parse_results['params'];
                    }

                }

            }
    }



    public static function getInstance()
    {
        // Access globals.
            global $argv;


        // Make sure we are in an environment where we have the $argv global.
            if (  !is_array($argv)  ) {
                // Error.
                return null;
            }


        // Get instance.
            static $singleton = null;

            if (  ! $singleton instanceof self  ) {

                $singleton = new self($argv);
            }


        // Return.
            return $singleton;
    }



    public function getParams()
    {
        return $this->params;
    }

    public function getSwitches()
    {
        return $this->switches;
    }

    public function getArgv()
    {
        return $this->argv;
    }


    public function getSwitch($name, $default = null)
    {
        // Initialize.
            $result = $default;


        //
            if (  isset( $this->switches[$name] )  ) {
                $result = $this->switches[$name];
            }


        // Return.
            return $result;
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////// C L A S S E S //
